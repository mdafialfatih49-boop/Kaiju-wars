package com.kaiju;

import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;

public class KaijuWar implements ModInitializer {
    public static final String MOD_ID = "kaijuwar";

    @Override
    public void onInitialize() {
        ModEntities.register();
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("kaijuwar")
                        .requires(src -> src.hasPermissionLevel(2))
                        .executes(KaijuWar::startWar)));
    }

    /** /kaijuwar : memunculkan 7 kaiju melingkar 45 blok dari pemain; mereka langsung saling serang. */
    private static int startWar(CommandContext<ServerCommandSource> ctx) {
        ServerCommandSource src = ctx.getSource();
        ServerWorld world = src.getWorld();
        Vec3d c = src.getPosition();
        Kind[] kinds = Kind.values();
        for (int i = 0; i < kinds.length; i++) {
            double a = Math.PI * 2 * i / kinds.length;
            double x = c.x + Math.cos(a) * 45;
            double z = c.z + Math.sin(a) * 45;
            int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING, (int) x, (int) z);
            KaijuEntity e = ModEntities.TYPES.get(kinds[i]).create(world);
            if (e == null) continue;
            float yaw = (float) Math.toDegrees(Math.atan2(c.x - x, -(c.z - z)));
            e.refreshPositionAndAngles(x, y, z, yaw, 0f);
            world.spawnEntity(e);
        }
        src.sendFeedback(() -> Text.literal("Perang Kaiju dimulai!"), true);
        return 1;
    }
}
