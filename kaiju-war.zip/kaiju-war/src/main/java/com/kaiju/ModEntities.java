package com.kaiju;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.Map;

public final class ModEntities {
    public static final Map<Kind, EntityType<KaijuEntity>> TYPES = new EnumMap<>(Kind.class);
    public static final Map<Kind, Item> EGGS = new EnumMap<>(Kind.class);

    private ModEntities() {}

    public static void register() {
        for (Kind k : Kind.values()) {
            FabricEntityTypeBuilder<KaijuEntity> b = FabricEntityTypeBuilder.<KaijuEntity>create(
                            SpawnGroup.MONSTER, (t, w) -> new KaijuEntity(t, w, k))
                    .dimensions(EntityDimensions.fixed(k.width(), k.height()))
                    .trackRangeBlocks(200);
            if (k.fireImmune) b = b.fireImmune();

            EntityType<KaijuEntity> type = Registry.register(Registries.ENTITY_TYPE,
                    new Identifier(KaijuWar.MOD_ID, k.id), b.build());
            FabricDefaultAttributeRegistry.register(type, KaijuEntity.attributes(k));
            TYPES.put(k, type);

            Item egg = Registry.register(Registries.ITEM,
                    new Identifier(KaijuWar.MOD_ID, k.id + "_spawn_egg"),
                    new SpawnEggItem(type, k.eggPrimary, k.eggSecondary, new FabricItemSettings()));
            EGGS.put(k, egg);
        }
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(entries -> {
            for (Item i : EGGS.values()) entries.add(i);
        });
    }
}
