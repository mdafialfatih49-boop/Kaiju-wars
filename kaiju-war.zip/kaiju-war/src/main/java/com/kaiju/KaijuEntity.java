package com.kaiju;

import net.minecraft.block.BlockState;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class KaijuEntity extends PathAwareEntity {
    public final Kind kind;
    private int specialCooldown = 40;

    public KaijuEntity(EntityType<? extends KaijuEntity> type, World world, Kind kind) {
        super(type, world);
        this.kind = kind;
        this.experiencePoints = 500;
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder attributes(Kind k) {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, k.health)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, k.damage)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, k.speed)
                .add(EntityAttributes.GENERIC_ARMOR, 15.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0)
                .add(EntityAttributes.GENERIC_ATTACK_KNOCKBACK, 3.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 128.0);
    }

    @Override
    protected void initGoals() {
        // Catatan: dipanggil dari konstruktor induk, jadi 'kind' hanya dibaca di dalam lambda.
        goalSelector.add(1, new SwimGoal(this));
        goalSelector.add(2, new MeleeAttackGoal(this, 1.25, true));
        goalSelector.add(5, new WanderAroundFarGoal(this, 0.9));
        goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 24f));
        goalSelector.add(7, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this));
        // Langsung incar kaiju JENIS LAIN, tanpa perlu melihat (agresif).
        targetSelector.add(2, new ActiveTargetGoal<KaijuEntity>(this, KaijuEntity.class, 0, false, false,
                e -> e instanceof KaijuEntity k && k.kind != this.kind));
    }

    private boolean isEnemy(LivingEntity e) {
        return e instanceof KaijuEntity k && k.kind != this.kind;
    }

    private List<LivingEntity> enemiesNear(Vec3d c, double r) {
        return getWorld().getEntitiesByClass(LivingEntity.class,
                new Box(c.x - r, c.y - r, c.z - r, c.x + r, c.y + r, c.z + r),
                x -> x != this && x.isAlive() && isEnemy(x));
    }

    private void smite(LivingEntity e, float dmg) {
        e.damage(getDamageSources().mobAttack(this), dmg);
    }

    @Override
    public boolean tryAttack(Entity target) {
        boolean hit = super.tryAttack(target);
        if (hit && target instanceof LivingEntity le) {
            switch (kind) {
                case MAGMA_REX -> le.setOnFireFor(10);
                case VENOMTAIL -> {
                    le.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 200, 3));
                    le.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 100, 2));
                }
                case FROSTJAW -> le.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 2));
                case BLADEHEAD -> le.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 100, 2));
                case SHADOW_COLOSSUS -> heal(8f);
                default -> { }
            }
        }
        return hit;
    }

    @Override
    public void tick() {
        super.tick();
        if (!(getWorld() instanceof ServerWorld sw)) return;

        // Lompat/naik saat menabrak tebing atau blok (kaiju besar tidak bisa "step up" biasa).
        if (this.horizontalCollision && this.isOnGround()) {
            Vec3d v = getVelocity();
            setVelocity(v.x, 0.65, v.z);
        }

        LivingEntity t = getTarget();
        if (t == null || !t.isAlive()) return;
        if (specialCooldown > 0) { specialCooldown--; return; }
        useSpecial(sw, t);
    }

    private void useSpecial(ServerWorld sw, LivingEntity t) {
        double d2 = squaredDistanceTo(t);
        switch (kind) {
            case ATOMIC_TITAN -> {
                if (d2 > 25 && d2 < 1600) {
                    getLookControl().lookAt(t, 30f, 30f);
                    Vec3d from = getEyePos();
                    Vec3d dir = t.getEyePos().subtract(from).normalize();
                    Set<LivingEntity> hits = new HashSet<>();
                    for (int i = 2; i <= 32; i++) {
                        Vec3d p = from.add(dir.multiply(i));
                        sw.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, p.x, p.y, p.z, 8, 0.4, 0.4, 0.4, 0.02);
                        sw.spawnParticles(ParticleTypes.CLOUD, p.x, p.y, p.z, 1, 0.3, 0.3, 0.3, 0.01);
                        hits.addAll(enemiesNear(p, 2.5));
                    }
                    for (LivingEntity e : hits) { smite(e, 35f); e.setOnFireFor(8); }
                    playSound(SoundEvents.ENTITY_BLAZE_SHOOT, 4f, 0.4f);
                    specialCooldown = 100;
                }
            }
            case BLADEHEAD -> {
                if (d2 > 64 && d2 < 2500) {
                    Vec3d dir = t.getPos().subtract(getPos()).multiply(1, 0, 1).normalize();
                    addVelocity(dir.x * 2.2, 0.3, dir.z * 2.2);
                    velocityModified = true;
                    playSound(SoundEvents.ENTITY_RAVAGER_ROAR, 3f, 0.6f);
                    specialCooldown = 60;
                }
            }
            case STORMBACK -> {
                if (d2 < 2500) {
                    LightningEntity l = EntityType.LIGHTNING_BOLT.create(sw);
                    if (l != null) {
                        l.setPosition(t.getPos());
                        l.setCosmetic(true);
                        sw.spawnEntity(l);
                    }
                    smite(t, 35f);
                    specialCooldown = 50;
                }
            }
            case FROSTJAW -> {
                if (d2 < 225) {
                    for (LivingEntity e : enemiesNear(getPos(), 14)) {
                        smite(e, 15f);
                        e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 120, 4));
                        e.setFrozenTicks(200);
                    }
                    sw.spawnParticles(ParticleTypes.SNOWFLAKE, getX(), getY() + getHeight() / 2, getZ(),
                            200, 7, 2, 7, 0.1);
                    playSound(SoundEvents.BLOCK_GLASS_BREAK, 4f, 0.4f);
                    specialCooldown = 70;
                }
            }
            case MAGMA_REX -> {
                if (d2 < 144) {
                    for (LivingEntity e : enemiesNear(getPos(), 10)) {
                        smite(e, 25f);
                        e.setOnFireFor(10);
                        e.addVelocity(0, 0.8, 0);
                    }
                    sw.spawnParticles(ParticleTypes.LAVA, getX(), getY() + 0.5, getZ(), 80, 5, 0.5, 5, 0.2);
                    sw.spawnParticles(ParticleTypes.FLAME, getX(), getY() + 0.5, getZ(), 120, 6, 1, 6, 0.1);
                    playSound(SoundEvents.ENTITY_GENERIC_EXPLODE, 4f, 0.5f);
                    specialCooldown = 60;
                }
            }
            case VENOMTAIL -> {
                if (d2 > 16 && d2 < 900) {
                    sw.spawnParticles(ParticleTypes.WARPED_SPORE, t.getX(), t.getY() + 1, t.getZ(),
                            120, 3, 1.5, 3, 0.05);
                    for (LivingEntity e : enemiesNear(t.getPos(), 5)) {
                        smite(e, 20f);
                        e.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 200, 3));
                        e.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 100, 2));
                    }
                    playSound(SoundEvents.ENTITY_SPIDER_HURT, 3f, 0.4f);
                    specialCooldown = 80;
                }
            }
            case SHADOW_COLOSSUS -> {
                if (d2 > 64 && d2 < 2500) {
                    Vec3d look = t.getRotationVec(1f).multiply(1, 0, 1).normalize();
                    Vec3d back = t.getPos().subtract(look.multiply(6));
                    Box moved = getBoundingBox().offset(back.x - getX(), 0, back.z - getZ());
                    if (sw.isSpaceEmpty(this, moved)) {
                        sw.spawnParticles(ParticleTypes.PORTAL, getX(), getY() + 2, getZ(), 80, 1, 2, 1, 0.5);
                        refreshPositionAndAngles(back.x, t.getY(), back.z, getYaw(), getPitch());
                        getNavigation().stop();
                        sw.spawnParticles(ParticleTypes.PORTAL, getX(), getY() + 2, getZ(), 80, 1, 2, 1, 0.5);
                        t.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 100, 0));
                        heal(30f);
                        playSound(SoundEvents.ENTITY_ENDERMAN_TELEPORT, 3f, 0.4f);
                        specialCooldown = 100;
                    }
                }
            }
        }
    }

    @Override public boolean canImmediatelyDespawn(double distanceSquared) { return false; }

    @Override
    public boolean handleFallDamage(float fallDistance, float damageMultiplier, DamageSource source) {
        return false;
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_RAVAGER_ROAR; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.ENTITY_RAVAGER_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_RAVAGER_DEATH; }
    @Override public float getSoundPitch() { return 0.55f + random.nextFloat() * 0.1f; }
    @Override protected float getSoundVolume() { return 3f; }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        playSound(SoundEvents.ENTITY_IRON_GOLEM_STEP, 1.5f, 0.5f);
    }
}
